export const FILTER_LIST = 'FILTER_LIST'

export const filterList = (filtered_list)=> ({ 
    type: FILTER_LIST,
    filtered_list: filtered_list
})

